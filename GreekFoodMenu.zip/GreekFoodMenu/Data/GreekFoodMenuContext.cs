﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GreekFoodMenu.Models;

namespace GreekFoodMenu.Data
{
    public class GreekFoodMenuContext : DbContext
    {
        public GreekFoodMenuContext (DbContextOptions<GreekFoodMenuContext> options)
            : base(options)
        {
        }

        public DbSet<GreekFoodMenu.Models.Meal> Meal { get; set; } = default!;
    }
}
