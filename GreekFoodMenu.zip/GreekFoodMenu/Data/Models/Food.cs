﻿using System;
using System.Collections.Generic;

namespace GreekFoodMenu.Data.Models;

public partial class Food
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public decimal? Price { get; set; }

    public int? Weight { get; set; }

    public string? Ingredients { get; set; }

    public string? ImagePath { get; set; }
}
