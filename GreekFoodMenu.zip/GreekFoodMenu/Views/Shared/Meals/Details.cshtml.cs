﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using GreekFoodMenu.Data;
using GreekFoodMenu.Models;

namespace GreekFoodMenu.Views.Shared.Meals
{
    public class DetailsModel : PageModel
    {
        private readonly GreekFoodMenu.Data.GreekFoodMenuContext _context;

        public DetailsModel(GreekFoodMenu.Data.GreekFoodMenuContext context)
        {
            _context = context;
        }

        public Meal Meal { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var meal = await _context.Meal.FirstOrDefaultAsync(m => m.Id == id);
            if (meal == null)
            {
                return NotFound();
            }
            else
            {
                Meal = meal;
            }
            return Page();
        }
    }
}
