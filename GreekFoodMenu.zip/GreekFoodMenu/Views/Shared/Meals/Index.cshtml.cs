﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using GreekFoodMenu.Data;
using GreekFoodMenu.Models;

namespace GreekFoodMenu.Views.Shared.Meals
{
    public class IndexModel : PageModel
    {
        private readonly GreekFoodMenu.Data.GreekFoodMenuContext _context;

        public IndexModel(GreekFoodMenu.Data.GreekFoodMenuContext context)
        {
            _context = context;
        }

        public IList<Meal> Meal { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Meal = await _context.Meal.ToListAsync();
        }
    }
}
